import graphviz
import os
import re

fromPath = './out/'

for file in os.listdir(fromPath):
    if re.search("\.gv\Z", file):
        print ("Processing file: " + file)
        g = graphviz.Source.from_file(fromPath + file, format='png', engine='neato')
        g.render(filename=file[:-3], directory=fromPath, cleanup=True)
        os.remove(fromPath + file)